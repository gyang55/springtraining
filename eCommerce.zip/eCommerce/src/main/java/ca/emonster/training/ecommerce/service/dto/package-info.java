/**
 * Data Transfer Objects.
 */
package ca.emonster.training.ecommerce.service.dto;
