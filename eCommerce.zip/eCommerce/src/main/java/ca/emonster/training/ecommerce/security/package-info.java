/**
 * Spring Security configuration.
 */
package ca.emonster.training.ecommerce.security;
