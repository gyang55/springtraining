/**
 * Spring Data JPA repositories.
 */
package ca.emonster.training.ecommerce.repository;
