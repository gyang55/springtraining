/**
 * View Models used by Spring MVC REST controllers.
 */
package ca.emonster.training.ecommerce.web.rest.vm;
