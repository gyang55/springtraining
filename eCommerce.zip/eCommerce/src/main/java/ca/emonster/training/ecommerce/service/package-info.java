/**
 * Service layer beans.
 */
package ca.emonster.training.ecommerce.service;
