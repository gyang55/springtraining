package ca.emonster.training.ecommerce.domain.enumeration;

/**
 * The Currency enumeration.
 */
public enum Currency {
    CAD,
    USD,
}
