/**
 * JPA domain objects.
 */
package ca.emonster.training.ecommerce.domain;
