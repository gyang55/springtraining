/**
 * Spring Framework configuration files.
 */
package ca.emonster.training.ecommerce.config;
