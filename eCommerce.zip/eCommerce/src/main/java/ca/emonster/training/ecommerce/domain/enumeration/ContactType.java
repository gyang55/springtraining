package ca.emonster.training.ecommerce.domain.enumeration;

/**
 * The ContactType enumeration.
 */
public enum ContactType {
    CUSTOMER,
    SHIPPING,
}
